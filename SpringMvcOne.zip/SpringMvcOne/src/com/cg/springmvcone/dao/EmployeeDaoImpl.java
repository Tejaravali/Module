package com.cg.springmvcone.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.cg.springmvcone.dto.Employee;


@Repository("employeedao")
public class EmployeeDaoImpl implements IEmployeeDao
{
	@PersistenceContext
	EntityManager entitymanager;

	@Override
	public int addEmployeeData(Employee emp) 
	{
		entitymanager.persist(emp);
		entitymanager.flush();
		return emp.getEmpId();
		
	}

	@Override
	public List<Employee> showAllEmployee() 
	{
		Query queryone=entitymanager.createQuery("FROM Employee");
		List<Employee> myList= queryone.getResultList();
		return myList;
	}

	@Override
	public void deleteEmployee(int empId) 
	{
		Query queryTwo=entitymanager.createQuery("DELETE FROM Employee WHERE empId=:eid");
		queryTwo.setParameter("eid",empId);
		queryTwo.executeUpdate();
	}

	@Override
	public void updateEmployee(Employee emp)
	{

		entitymanager.merge(emp);
		entitymanager.flush();
		
		
	}

	@Override
	public List<Employee> searchEmployee(int empId)
	{
		Query queryTwo=entitymanager.createQuery("SELECT t FROM Employee t WHERE empId=:eid");
		queryTwo.setParameter("eid", empId);
		List<Employee> myList1= queryTwo.getResultList();
		return myList1;
       
	
	}

}
