package com.cg.springmvcone.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;



import com.cg.springmvcone.dao.IEmployeeDao;
import com.cg.springmvcone.dto.Employee;

@Service("employeeservice")
@Transactional
public class EmployeeServiceImpl implements IEmployeeService
{
	@Autowired
	IEmployeeDao employeedao;
	@Override
	public int addEmployeeData(Employee emp)
	{
		return employeedao.addEmployeeData(emp);
		
	}

	@Override
	public List<Employee> showAllEmployee() 
	{
		return employeedao. showAllEmployee(); 
	}

	@Override
	public void deleteEmployee(int empId) 
	{
		employeedao.deleteEmployee(empId);
		
	}

	@Override
	public void updateEmployee(Employee emp) 
	{
		employeedao.updateEmployee(emp);
	}

	@Override
	public List<Employee> searchEmployee(int empId)
	{
		return employeedao.searchEmployee(empId);
	}

}
