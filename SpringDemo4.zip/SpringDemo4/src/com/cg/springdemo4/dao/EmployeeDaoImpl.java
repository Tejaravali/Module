package com.cg.springdemo4.dao;

import org.springframework.stereotype.Repository;


@Repository("employeedao")
public class EmployeeDaoImpl implements IEmployeeDao
{

	@Override
	public void getData1() {
		System.out.println("In Dao Layer");
		
	}

}
