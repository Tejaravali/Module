package com.cg.springdemo4.dao;

public interface IEmployeeDao {
	public void getData1();
}
