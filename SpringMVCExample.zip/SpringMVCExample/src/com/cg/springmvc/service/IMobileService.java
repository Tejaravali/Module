package com.cg.springmvc.service;

import java.util.List;

import com.cg.springmvc.dto.MobileBean;

public interface IMobileService 
{
	public List<MobileBean> showAllMobile();
	public void deleteMobile(int mobId);
	public void updateMobile(MobileBean mob);
	public List<MobileBean> showMobilebyId(int id);
}
