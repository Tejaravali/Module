package com.cg.mobilemvc.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="mobiledata")
public class Mobile 
{
	@Id
	@Column(name="MOB_ID")
	private int mobId;
	@Column(name="MOB_NAME")
	private String mobName;
	@Column(name="MOB_CAT")
	private String category;
	@Column(name="MOB_PRICE")
	private double mobPrice;
	@Column(name="MOB_ONLINE")
	private String mobOnline;
	public int getMobId() {
		return mobId;
	}
	public void setMobId(int mobId) {
		this.mobId = mobId;
	}
	public String getMobName() {
		return mobName;
	}
	public void setMobName(String mobName) {
		this.mobName = mobName;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public double getMobPrice() {
		return mobPrice;
	}
	public void setMobPrice(double mobPrice) {
		this.mobPrice = mobPrice;
	}
	public String getMobOnline() {
		return mobOnline;
	}
	public void setMobOnline(String mobOnline) {
		this.mobOnline = mobOnline;
	}
	
	
	
}
