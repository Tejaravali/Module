package com.cg.mobilemvc.service;

import java.util.List;

import com.cg.mobilemvc.dto.Mobile;



public interface IMobileService 
{
	public void addMobileData(Mobile mob);
	public List<Mobile> showAllMobiles();
	
	public void deleteMobile(int mobId);
}
