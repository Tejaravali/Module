package com.cg.mobilemvc.dao;

import java.util.List;

import com.cg.mobilemvc.dto.Mobile;

public interface IMobileDao 
{
	public void addMobileData(Mobile mob);
	public List<Mobile> showAllMobiles();
	public void deleteMobile(int mobId);
}
