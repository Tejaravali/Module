package com.cg.mobilemvc.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.cg.mobilemvc.dto.Mobile;


@Repository("mobiledao")
public class MobileDaoImpl implements IMobileDao
{
	@PersistenceContext
	EntityManager entitymanager;
	@Override
	public void addMobileData(Mobile mob) {
		// TODO Auto-generated method stub
		System.out.println(mob);
		entitymanager.persist(mob);
		entitymanager.flush();
	}

	@Override
	public List<Mobile> showAllMobiles() {
		// TODO Auto-generated method stub
		Query queryOne=entitymanager.createQuery("FROM Mobile");
		List<Mobile> myList= queryOne.getResultList();
		return myList;
	}

	@Override
	public void deleteMobile(int mobId) {
		// TODO Auto-generated method stub
		Query queryTwo=entitymanager.createQuery("DELETE FROM Mobile WHERE mobId=:mid");
		queryTwo.setParameter("mid", mobId);
		queryTwo.executeUpdate();
		
	}

}
