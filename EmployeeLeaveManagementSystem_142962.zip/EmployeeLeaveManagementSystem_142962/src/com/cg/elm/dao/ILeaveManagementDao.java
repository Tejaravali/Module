package com.cg.elm.dao;

import java.util.List;

import com.cg.elm.dto.*;

public interface ILeaveManagementDao 
{
	public List<EmployeeLeaveDetails> fetchLeaveDetailsByEmpId(long empId);
	public List<Long> fetchAllEmployeeId();
	public Employee fetchEmployeeById(long employeeId);
}
