package com.cg.elm.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.cg.elm.dto.Employee;
import com.cg.elm.dto.EmployeeLeaveDetails;

@Repository("leaveDao")
public class LeaveManagementDaoImpl implements ILeaveManagementDao
{
	@PersistenceContext
	EntityManager entityManager;
	@Override
	public List<EmployeeLeaveDetails> fetchLeaveDetailsByEmpId(long empId) 
	{
		Query select_query=entityManager.createQuery("SELECT e FROM EmployeeLeaveDetails e WHERE employeeId=:eid");
		select_query.setParameter("eid", empId);
		List<EmployeeLeaveDetails> empList=  select_query.getResultList();
		return empList;
	}

	@Override
	public List<Long> fetchAllEmployeeId()
	{
		Query fetchEmployeeIdQuery=entityManager.createQuery("SELECT emp.employeeId FROM Employee emp");
		List<Long> eList=fetchEmployeeIdQuery.getResultList();
		return eList;
		
	}

	@Override
	public Employee fetchEmployeeById(long employeeId) 
	{
		Employee employee=entityManager.find(Employee.class, employeeId);
		return employee;
	}

}
