package com.cg.elm.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.elm.dao.ILeaveManagementDao;
import com.cg.elm.dto.Employee;
import com.cg.elm.dto.EmployeeLeaveDetails;

@Service("leaveService")
@Transactional
public class LeaveManagementServiceImpl implements ILeaveManagementService 
{
	@Autowired
	ILeaveManagementDao leaveDao;
	@Override
	public List<EmployeeLeaveDetails> fetchLeaveDetailsByEmpId(long empId) 
	{
		return leaveDao.fetchLeaveDetailsByEmpId(empId);
	}

	@Override
	public Employee fetchEmployeeById(long employeeId) 
	{
		return leaveDao.fetchEmployeeById(employeeId);
	}

	@Override
	public boolean isValidEmployeeId(long employeeId) 
	{
		List<Long> eList=leaveDao.fetchAllEmployeeId();
		for(Long l:eList)
		{
			if(l==employeeId)
			{
				return true;
			}
		}
		return false;
	}
	
}
