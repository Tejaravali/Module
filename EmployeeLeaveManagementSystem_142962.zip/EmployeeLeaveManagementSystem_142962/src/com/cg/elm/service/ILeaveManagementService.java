package com.cg.elm.service;

import java.util.List;

import com.cg.elm.dto.Employee;
import com.cg.elm.dto.EmployeeLeaveDetails;

public interface ILeaveManagementService 
{
	public List<EmployeeLeaveDetails> fetchLeaveDetailsByEmpId(long empId);
	public Employee fetchEmployeeById(long employeeId);
	public boolean isValidEmployeeId(long employeeId);
}
