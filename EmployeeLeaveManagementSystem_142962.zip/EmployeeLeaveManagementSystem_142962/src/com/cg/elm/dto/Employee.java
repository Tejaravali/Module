package com.cg.elm.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="employee_details")
public class Employee 
{
	@Id
	@Column(name="empid")
	private long employeeId;
	@Column(name="ename")
	private String employeeName;
	@Column(name="address")
	private String employeeAddress;
	@Column(name="leaves_avail")
	private int leavesAvail;
	public long getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(long employeeId) {
		this.employeeId = employeeId;
	}
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public String getEmployeeAddress() {
		return employeeAddress;
	}
	public void setEmployeeAddress(String employeeAddress) {
		this.employeeAddress = employeeAddress;
	}
	public int getLeavesAvail() {
		return leavesAvail;
	}
	public void setLeavesAvail(int leavesAvail) {
		this.leavesAvail = leavesAvail;
	}
	public Employee() {
		super();
	}
	public Employee(long employeeId, String employeeName,
			String employeeAddress, int leavesAvail) {
		this.employeeId = employeeId;
		this.employeeName = employeeName;
		this.employeeAddress = employeeAddress;
		this.leavesAvail = leavesAvail;
	}
	@Override
	public String toString() {
		return "Employee [employeeId=" + employeeId + ", employeeName="
				+ employeeName + ", employeeAddress=" + employeeAddress
				+ ", leavesAvail=" + leavesAvail + "]";
	}
}
