package com.cg.elm.dto;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

@Entity
@Table(name="employee_leave_details")
public class EmployeeLeaveDetails 
{
	@Id
	@Column(name="leave_id")
	private int leaveId;
	@Column(name="empid")
	@NotNull(message="Employee Id should not be empty")
	private Long employeeId;
	@Column(name="start_date")
	private Date startDate;
	@Column(name="end_date")
	private Date endDate;
	private String description;
	@Column(name="leaves_applied")
	private int leavesApplied;
	public int getLeaveId() {
		return leaveId;
	}
	public void setLeaveId(int leaveId) {
		this.leaveId = leaveId;
	}
	public Long getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(Long employeeId) {
		this.employeeId = employeeId;
	}
	public Date getStartDate() {
		return startDate;
	}
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}
	public Date getEndDate() {
		return endDate;
	}
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public int getLeavesApplied() {
		return leavesApplied;
	}
	public void setLeavesApplied(int leavesApplied) {
		this.leavesApplied = leavesApplied;
	}
	public EmployeeLeaveDetails() {
		super();
	}
	public EmployeeLeaveDetails(int leaveId, Long employeeId,
			Date startDate, Date endDate, String description,
			int leavesApplied) {
		this.leaveId = leaveId;
		this.employeeId = employeeId;
		this.startDate = startDate;
		this.endDate = endDate;
		this.description = description;
		this.leavesApplied = leavesApplied;
	}
	@Override
	public String toString() {
		return "EmployeeLeaveDetails [leaveId=" + leaveId + ", employeeId="
				+ employeeId + ", startDate=" + startDate + ", endDate="
				+ endDate + ", description=" + description + ", leavesApplied="
				+ leavesApplied + "]";
	}
}
