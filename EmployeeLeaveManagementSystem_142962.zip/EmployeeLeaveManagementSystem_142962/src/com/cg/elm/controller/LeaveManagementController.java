package com.cg.elm.controller;

import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.cg.elm.dto.Employee;
import com.cg.elm.dto.EmployeeLeaveDetails;
import com.cg.elm.service.ILeaveManagementService;

@Controller
public class LeaveManagementController 
{
	@Autowired
	ILeaveManagementService leaveService;
	
	/*The request with value 'enterEmployeeId' is caught here*/
	@RequestMapping(value="enterEmployeeId",method=RequestMethod.GET)
	public String enterEmployeeId(@ModelAttribute("leaveDetail") EmployeeLeaveDetails leaveDetail ) 
	{
		/*Redirects to 'Home.jsp' page*/
		return "Home";
	}
	/*The request with value 'getLeaveDetails' is caught here*/
	@RequestMapping(value="getLeaveDetails",method=RequestMethod.POST)
	public ModelAndView fetchEmployeeLeaveDetails(@Valid @ModelAttribute("leaveDetail") EmployeeLeaveDetails leaveDetail,Map<String,Object> model,BindingResult result)
	{
		try
		{
		/*Checks for the errors in objects that are bound in ModelAttribute*/
		if(result.hasErrors())
		{
			return new ModelAndView("Home");
		}
		else
		{
			/*checks whether the given Employee ID is valid or not*/
			if(leaveService.isValidEmployeeId(leaveDetail.getEmployeeId()))
			{
				Employee emp=leaveService.fetchEmployeeById(leaveDetail.getEmployeeId());
				List<EmployeeLeaveDetails> leaveDetails=leaveService.fetchLeaveDetailsByEmpId(leaveDetail.getEmployeeId());
				/*Puts the 'leaveListl in model*/
				model.put("leaveList",leaveDetails);
				/*Puts the employee object in model*/
				model.put("employee", emp);
				/*Opens the view of 'viewLeaveDetails'*/
				return new ModelAndView("ViewLeaveDetails");
			}
			else
			{
				String msg="This Employee ID Does not exist..";
				/*Puts the error message in model*/
				model.put("error",msg);
				/*Returns to home page if Employee ID is not valid */
				return new ModelAndView("Home");
			}
		}
	}
	catch(Exception e)
	{
		String errorMessage=e.getMessage();
		return new ModelAndView("Error","error",errorMessage);
	}
	}
}
