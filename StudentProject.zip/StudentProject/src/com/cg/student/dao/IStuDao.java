package com.cg.student.dao;

import java.util.List;

import com.cg.student.dto.Student;

public interface IStuDao 
{
	public int addStudent(Student stu);
	public void deleteStu(int stuId);
	public void updateStu(Student stu);
	public Student search(int stuId);
	public List<Student> showAll();
}
