package com.cg.student.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;


import com.cg.student.dto.Student;

@Repository("studentdao")
public class StuDaoImpl implements IStuDao
{
	@PersistenceContext
	EntityManager entitymanager;
	@Override
	public int addStudent(Student stu) {
		entitymanager.persist(stu);
		entitymanager.flush();
		return stu.getStuId();
	}

	@Override
	public void deleteStu(int stuId) {
		Query queryOne=entitymanager.createQuery("DELETE FROM Student WHERE stuId=:sid");
		queryOne.setParameter("sid", stuId);
		queryOne.executeUpdate();
		
	}

	@Override
	public void updateStu(Student stu) {
		entitymanager.merge(stu);
		entitymanager.flush();
		
	}

	@Override
	public Student search(int stuId) {
		Student student=entitymanager.find(Student.class, stuId);
		return student;
		
	}

	@Override
	public List<Student> showAll() {
		Query queryOne=entitymanager.createQuery("FROM Student");
		List<Student> myList= queryOne.getResultList();
		return myList;
	}

}
