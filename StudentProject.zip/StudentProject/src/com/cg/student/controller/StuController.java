package com.cg.student.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;


import org.springframework.web.servlet.ModelAndView;











import com.cg.student.dto.Student;
import com.cg.student.service.IStuService;





@Controller
public class StuController 
{

	@Autowired
	IStuService studentservice;

	@RequestMapping(value="all",method=RequestMethod.GET)
	public String getAll()
	{
		
		return "home";
	}
	
	@RequestMapping(value="add",method=RequestMethod.GET)
	public String addEmployee(@ModelAttribute("my") Student stu,Map<String,Object> model)
	{
		List<String> myDeg=new ArrayList<>();
		myDeg.add("CSE");
		myDeg.add("IT");
		myDeg.add("MECH");
		myDeg.add("EEE");
		model.put("deg", myDeg);
		return "addstudent";
	}
	
	@RequestMapping(value="insertdata",method=RequestMethod.POST)
	public String addTraineeDetails(@ModelAttribute ("my")Student stu,Map<String,Object> model)
	{
		
		int id = studentservice.addStudent(stu);
		return "home";
	}
	
	@RequestMapping(value="delete",method=RequestMethod.GET)
	public String deleteStu()
	{
		return "delete";
	}
	
	@RequestMapping(value="dodelete",method=RequestMethod.GET)
	public String employeeDelete(@RequestParam("sid") int id)
	{
		//System.out.println("Id is ...."+id);
		studentservice.deleteStu(id);
		return "home";
	}
	
	@RequestMapping(value="update",method=RequestMethod.GET)
	public String updateStud()
	{
		return "modify";
	}
	
	@RequestMapping(value="updateStudent",method=RequestMethod.GET)
	public ModelAndView updateTrainee(@RequestParam ("sid") int id,@ModelAttribute ("myUpdate") Student stu)
	{
		
		Student myData= studentservice.search(id);
		return new ModelAndView( "updateStu","temp",myData);
	}
	
	@RequestMapping(value="up",method=RequestMethod.POST)
	public String update(@ModelAttribute ("myUpdate") Student stu)
	{
		
		studentservice.updateStu(stu);
		return "home";
	}
	

	@RequestMapping(value="search",method=RequestMethod.GET)
	public String showEmployeeById()
	{
		return "showSearch";
	}
	
	@RequestMapping(value="showStu",method=RequestMethod.GET)
	public ModelAndView showEmployee(@RequestParam ("sid") int id)
	{
		Student myData1=studentservice.search(id);
		return new ModelAndView( "show","temp",myData1);
		
	}
	
	@RequestMapping(value="showall",method=RequestMethod.GET)
	public ModelAndView showAllEmployee()
	{
		List<Student> myAllData=studentservice.showAll();
		return new ModelAndView("showallStudents","temp",myAllData);
	}
	
	
}
