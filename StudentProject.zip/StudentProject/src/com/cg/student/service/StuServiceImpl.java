package com.cg.student.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.cg.student.dao.IStuDao;
import com.cg.student.dto.Student;

@Service("studentservice")
@Transactional
public class StuServiceImpl implements IStuService
{
	@Autowired
	IStuDao studentdao;
	@Override
	public int addStudent(Student stu)
	{
		return studentdao.addStudent(stu);
	}

	@Override
	public void deleteStu(int stuId) {
		// TODO Auto-generated method stub
		studentdao.deleteStu(stuId);
	}

	@Override
	public void updateStu(Student stu) {
		studentdao.updateStu(stu);
		
	}

	@Override
	public Student search(int stuId) {
		// TODO Auto-generated method stub
		return studentdao.search(stuId);
	}

	@Override
	public List<Student> showAll() {
		// TODO Auto-generated method stub
		return studentdao.showAll();
	}

}
