package com.cg.student.service;

import java.util.List;

import com.cg.student.dto.Student;

public interface IStuService 
{
	public int addStudent(Student stu);
	public void deleteStu(int stuId);
	public void updateStu(Student stu);
	public Student search(int stuId);
	public List<Student> showAll();
}
