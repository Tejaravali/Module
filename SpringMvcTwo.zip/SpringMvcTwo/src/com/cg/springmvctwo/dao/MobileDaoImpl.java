package com.cg.springmvctwo.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.cg.springmvctwo.dto.Mobile;

@Repository("mobiledao")
public class MobileDaoImpl implements IMobileDao
{
	@PersistenceContext
	EntityManager entitymanager;

	@Override
	public List<Mobile> showAllMobile() 
	{
		Query queryone=entitymanager.createQuery("FROM Mobile");
		List<Mobile> allData=queryone.getResultList();
		
		return allData;
	}

	@Override
	public void deleteMobile(int mobId)
	{
		
		
	}

	@Override
	public void updateMobile(Mobile mob)
	{
		
		
	}

}
