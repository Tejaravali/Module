package com.cg.springmvcmobile.dao;

import java.util.List;

import com.cg.springmvcmobile.dto.Mobile;

public interface IMobileDao 
{
	public void addMobileData(Mobile mob);
	public List<Mobile> showAllMobile();

}
