package com.cg.springmvcone.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import com.cg.springmvcone.dto.Employee;

@Repository("employeedao")
public class EmployeeDaoImpl implements IEmployeeDao {

	@PersistenceContext
	EntityManager em;
	@Override
	public int addEmployee(Employee emp) {
		em.persist(emp);
		em.flush();
		return emp.getEmpId();
	}

	@Override
	public List<Employee> showAllEmployee() {
		Query queryOne=em.createQuery("FROM Employee");
		List<Employee> myList=queryOne.getResultList();
		 return myList;
	}

	@Override
	public void deleteEmployee(int eId) {
		Query queryTwo=em.createQuery("DELETE FROM Employee WHERE empId=:eid");
		queryTwo.setParameter("eid", eId);
		queryTwo.executeUpdate();
	}

	@Override
	public void updateEmployee(Employee emp) {
		em.merge(emp);
		em.flush();
	}

	@Override
	public List<Employee> searchEmployee(int empId) {
		Query queryone=em.createQuery("SELECT e FROM Employee e WHERE empId=:eid");
		queryone.setParameter("eid", empId);
		List<Employee> emp=  queryone.getResultList();
		return emp;
	}
	}


