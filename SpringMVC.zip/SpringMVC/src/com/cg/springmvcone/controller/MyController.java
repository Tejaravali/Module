package com.cg.springmvcone.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.springmvcone.dto.Employee;
import com.cg.springmvcone.service.IEmployeeService;

@Controller
public class MyController
{
	@Autowired
	IEmployeeService employeeservice;
	@RequestMapping(value="all",method=RequestMethod.GET)
	public String getAll()
	{
		return "Home";
	}
	@RequestMapping(value="add",method=RequestMethod.GET)
	public String addEmployee(@ModelAttribute("my") Employee emp,Map<String, Object> model)
	{
		List<String> desig=new ArrayList<String>();
		desig.add("Software Engineer");
		desig.add("Sr Consultant");
		desig.add("Manager");
		model.put("deg", desig);
		return "AddEmployee";
	}
	@RequestMapping(value="insertdata",method=RequestMethod.POST)
	public ModelAndView insertEmployee(@Valid @ModelAttribute("my") Employee emp,BindingResult result,Map<String, Object> model)
	{
		int empId=0;
		if(result.hasErrors())
		{
			List<String> desig=new ArrayList<String>();
			desig.add("Software Engineer");
			desig.add("Sr Consultant");
			desig.add("Manager");
			model.put("deg", desig);
			return new ModelAndView("AddEmployee");
		}
		else
		{
			empId=employeeservice.addEmployee(emp);
			return new ModelAndView("insertSuccess","eid",empId);
		}
	}
	@RequestMapping(value="show",method=RequestMethod.GET)
	public ModelAndView showAllEmployee()
	{
		List<Employee> myAllData=employeeservice.showAllEmployee();
		return new ModelAndView("ShowAll","temp",myAllData);
	}
	@RequestMapping(value="delete",method=RequestMethod.GET)
	public String deleteEmployee()
	{
		return "deleteEmployee";
	}
	@RequestMapping(value="doDelete",method=RequestMethod.GET)
	public String employeeDelete(@RequestParam("eid") int id)
	{
		employeeservice.deleteEmployee(id);
		return "deleteSuccess";
	}
	@RequestMapping(value="search",method=RequestMethod.GET)
	public String searchEmployee()
	{
		return "searchEmployee";
	}
	@RequestMapping(value="fetch",method=RequestMethod.GET)
	public ModelAndView employeeSearch(@RequestParam("eid") int id)
	{
		List<Employee> myData=employeeservice.searchEmployee(id);
		return new ModelAndView("showEmployee","empdata",myData);
	}
	@RequestMapping(value="update",method=RequestMethod.GET)
	public String updateEmployee(@ModelAttribute ("myUpdate")Employee emp)
	{
		return "updateForm";
	}
	@RequestMapping(value="doUpdate",method=RequestMethod.GET)
	public ModelAndView updateShow(@RequestParam("eid") int id,@ModelAttribute ("myUpdate")Employee emp)
	{
		List<Employee> myData=employeeservice.searchEmployee(id);
		return new ModelAndView("showUpdate","empdata",myData);
	}
	@RequestMapping(value="updateEmp",method=RequestMethod.POST)
	public String employeeUpdate(@ModelAttribute ("myUpdate")Employee emp)
	{
		employeeservice.updateEmployee(emp);
		return "updateSuccess";
	}
}