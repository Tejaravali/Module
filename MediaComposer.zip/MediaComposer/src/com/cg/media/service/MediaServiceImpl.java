package com.cg.media.service;


import java.util.ArrayList;
import java.util.regex.Pattern;

import com.cg.media.bean.Artist_Master;
import com.cg.media.bean.Composer_Master;
import com.cg.media.bean.Song_Master;
import com.cg.media.dao.MediaDao;
import com.cg.media.dao.MediaDaoImpl;
import com.cg.media.exception.MediaException;

public class MediaServiceImpl implements MediaService
{

	MediaDao medDao=null;
    public MediaServiceImpl()
    {
    	medDao=new MediaDaoImpl();
    }
    
	@Override
	public int addComposer(Composer_Master cm) throws MediaException 
	{
		
		return medDao.addComposer(cm);
	}

	@Override
	public int addArtist(Artist_Master am) throws MediaException 
	{
		return medDao.addArtist(am);
	}

	@Override
	public Composer_Master getComposer(int composer_Id) throws MediaException 
	{
	
		return medDao.getComposer(composer_Id);
	}

	@Override
	public int addSongs(Song_Master sm) throws MediaException 
	{
		
		return medDao.addSongs(sm);
	}

	@Override
	public Song_Master getSong(int song_id) throws MediaException
	{
		
		return medDao.getSong(song_id);
	}

//	@Override
//	public ArrayList<Composer_Master> getComposer() throws MediaException {
//	
//		return medDao.getComposer();
//	}

	@Override
	public int updateComposer(int composer_id,Composer_Master cm) throws MediaException 
	{
		
		return medDao.updateComposer(composer_id,cm);
	}
	
	@Override
	public int updateArtist(int artist_id,Artist_Master am) throws MediaException
	{
		
		return medDao.updateArtist(artist_id,am);
	}

	@Override
	public ArrayList<Composer_Master> getComposerDetails(int composer_id)
			throws MediaException {
		// TODO Auto-generated method stub
		return medDao.getComposerDetails(composer_id);
	}
	
	@Override
	public int getUserId() throws MediaException {
		// TODO Auto-generated method stub
		return medDao.getUserId();
	}
	@Override
	public String getUserPwd() throws MediaException {
		// TODO Auto-generated method stub
		return medDao.getUserPwd();
	}
	@Override
	public int getAdminId() throws MediaException {
		// TODO Auto-generated method stub
		return medDao.getAdminId();
	}
	@Override
	public String getAdminPwd() throws MediaException {
		// TODO Auto-generated method stub
		return medDao.getAdminPwd();
	}
	@Override
	public boolean validateUserId(int user_id) throws MediaException 
	{
		int namePattern=medDao.getUserId();
		if(namePattern==user_id)
		{
			return true;
		}
		else
		{
			throw new MediaException("Invalid user id");
		}
	}
	@Override
	public boolean validateAdminId(int adminId) throws MediaException 
	{
		int namePattern=medDao.getAdminId();
		if(namePattern==adminId)
		{
			return true;
		}
		else
		{
			throw new MediaException("Invalid Admin id");
		}	}
	@Override
	public boolean validateUserPwd(String userPwd) throws MediaException
	{
		String namePattern=medDao.getUserPwd();
		if(Pattern.matches(namePattern,userPwd))
		{
			return true;
		}
		else
		{
			throw new MediaException("Invalid user password");
		}
	}
	@Override
	public boolean validateAdminPwd(String adminPwd) throws MediaException 
	{
		String namePattern=medDao.getAdminPwd();
		if(Pattern.matches(namePattern,adminPwd))
		{
			return true;
		}
		else
		{
			throw new MediaException("Invalid Admin password");
		}
	}

	

}
