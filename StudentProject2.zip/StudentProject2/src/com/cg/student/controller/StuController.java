package com.cg.student.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;


import org.springframework.web.servlet.ModelAndView;
import com.cg.student.dto.Student;
import com.cg.student.service.IStuService;





@Controller
public class StuController 
{

	@Autowired
	IStuService studentservice;

	@RequestMapping(value="all",method=RequestMethod.GET)
	public ModelAndView getAll()
	{
		
		List<Student> Data=studentservice.showAll();
		return new ModelAndView("showList","temp",Data);
	}
	
	
	
	@RequestMapping(value="delete",method=RequestMethod.GET)
	public String employeeDelete(@RequestParam("id") int stuId)
	{
		//System.out.println("Id is ...."+id);
		studentservice.deleteStu(stuId);
		return "redirect:/all";
	}
	
	
	@RequestMapping(value="update",method=RequestMethod.GET)
	public ModelAndView updateProduct(@RequestParam("id") int stuId,Map<String,Object> model,@ModelAttribute("product") Student student )
	{
		List<String> category=new ArrayList<String>();
		category.add("cse");
		category.add("EEE");
		category.add("it");
		model.put("cat", category);
		Student pro=studentservice.search(stuId);
		return new ModelAndView("UpdateStud","temp",pro);
	}
	
	@RequestMapping(value="up",method=RequestMethod.POST)
	public String update(@ModelAttribute ("myUpdate") Student stu)
	{
		
		studentservice.updateStu(stu);
		return "redirect:/all";
	}
	

	
	
}
