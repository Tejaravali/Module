package com.cg.student.dao;

import java.util.List;

import com.cg.student.dto.Student;

public interface IStuDao 
{
	
	public void deleteStu(int stuId);
	public void updateStu(Student stu);
	public Student search(int stuId);
	public List<Student> showAll();
}
