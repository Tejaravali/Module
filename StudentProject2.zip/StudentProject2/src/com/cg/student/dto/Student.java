package com.cg.student.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="studetails")
public class Student 
{
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="stu_seq")
	@SequenceGenerator(name="stu_seq",sequenceName="stu_id_seq")
	@Column(name="id")
	private Integer stuId;
	@Column(name="name")
	private String stuName;
	@Column(name="department")
	private String stuDept;
	@Column(name="gender")
	private String stuGen;
	public Integer getStuId() {
		return stuId;
	}
	public void setStuId(Integer stuId) {
		this.stuId = stuId;
	}
	public String getStuName() {
		return stuName;
	}
	public void setStuName(String stuName) {
		this.stuName = stuName;
	}
	public String getStuDept() {
		return stuDept;
	}
	public void setStuDept(String stuDept) {
		this.stuDept = stuDept;
	}
	public String getStuGen() {
		return stuGen;
	}
	public void setStuGen(String stuGen) {
		this.stuGen = stuGen;
	}
	
	
}
