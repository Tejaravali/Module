package com.cg.user.dto;

public interface EmployeeDetails 
{
	public void getAllEmployeeDetail();
	public void getSBUDetails();
}
