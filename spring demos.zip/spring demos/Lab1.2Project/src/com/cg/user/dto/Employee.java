package com.cg.user.dto;

public class Employee implements EmployeeDetails
{
	int employeeId;
	String employeeName;
	double salary;
	int age;
	SBUbean sOne;
	


	public int getEmployeeId() {
		return employeeId;
	}



	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}



	public String getEmployeeName() {
		return employeeName;
	}



	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}



	public double getSalary() {
		return salary;
	}



	public void setSalary(double salary) {
		this.salary = salary;
	}



	



	public SBUbean getsOne() {
		return sOne;
	}



	public void setsOne(SBUbean sOne) {
		this.sOne = sOne;
	}



	public int getAge() {
		return age;
	}



	public void setAge(int age) {
		this.age = age;
	}

	@Override
	public void getAllEmployeeDetail() {
		// TODO Auto-generated method stub
		System.out.println("Employee details");
		System.out.println("-------------------");
		System.out.println("Employee [ empAge ="+age+", empId ="+employeeId+", empName="+employeeName+", empSal="+salary);
		getSBUDetails();
	}



	@Override
	public void getSBUDetails() {
		// TODO Auto-generated method stub
		System.out.println("sbu details =SBU [sbuCode="+sOne.getSbuId()+", sbuHead="+sOne.getSbuHead()+",sbuName="+sOne.getSbuName()+"]]");
	}



	
}
