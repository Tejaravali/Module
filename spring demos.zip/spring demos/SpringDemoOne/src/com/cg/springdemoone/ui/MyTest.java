package com.cg.springdemoone.ui;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.springdemoone.dto.Employee;
import com.cg.springdemoone.dto.Shape;

public class MyTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ApplicationContext app=new ClassPathXmlApplicationContext("spring.xml");
		
		//Shape sp=(Shape) app.getBean("tran");
		//sp.getShape();
		
		Employee employee= (Employee) app.getBean("emp");
		employee.getAllDetails();

	}

}
