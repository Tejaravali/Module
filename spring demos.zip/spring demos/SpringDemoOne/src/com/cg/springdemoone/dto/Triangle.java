package com.cg.springdemoone.dto;

public class Triangle implements Shape
{

	@Override
	public void getShape() {
		// TODO Auto-generated method stub
		System.out.println("In Triangle......");
		
	}

}
