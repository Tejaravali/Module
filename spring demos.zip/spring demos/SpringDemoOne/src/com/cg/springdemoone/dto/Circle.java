package com.cg.springdemoone.dto;

public class Circle implements Shape
{

	@Override
	public void getShape() {
		// TODO Auto-generated method stub
		System.out.println("In Circle....");
		
	}

}
