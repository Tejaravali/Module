package com.cg.springdemoone.dto;

public interface Shape 
{
	public void getShape();
}
