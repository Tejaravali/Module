package com.cg.user.ui;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.user.dto.EmployeeDetail;




public class MyTest {

	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		ApplicationContext ap=new ClassPathXmlApplicationContext("spring.xml");
		EmployeeDetail e=(EmployeeDetail) ap.getBean("sbu");
		
		e.getAllSbuDetails();
	}

}
