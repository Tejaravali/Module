package com.cg.user.dto;

import java.util.List;



public class SBUbean implements EmployeeDetail
{
	 String sbuId;
	 String sbuName;
	 String sbuHead;
	 
	 List<Employee> empl;
	 
	 
	public List<Employee> getEmpl() {
		return empl;
	}
	public void setEmpl(List<Employee> empl) {
		this.empl = empl;
	}
	public  String getSbuId() {
		return sbuId;
	}
	public void setSbuId(String sbuId) {
		this.sbuId = sbuId;
	}
	public  String getSbuName() {
		return sbuName;
	}
	public void setSbuName(String sbuName) {
		this.sbuName = sbuName;
	}
	public  String getSbuHead() {
		return sbuHead;
	}
	public void setSbuHead(String sbuHead) {
		this.sbuHead = sbuHead;
	}
	
	@Override
	public void getAllSbuDetails()
	{
		System.out.println("SBU details");
		System.out.println("----------------");
		System.out.println("sbuCode="+sbuId+", sbuHead="+sbuHead+",sbuName="+sbuName);
		System.out.println("Employee Details:---------");
		for(Employee employee : empl)
		{
			System.out.println("[Employee [empAge="+employee.getAge()+", empName="+employee.getEmployeeName()+",empSalary="+employee.getSalary()+"]]");
			
		}
	}
	
	
}
