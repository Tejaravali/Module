package com.cg.user.dto;

public interface EmployeeDetail
{
	public void getAllSbuDetails();
}
