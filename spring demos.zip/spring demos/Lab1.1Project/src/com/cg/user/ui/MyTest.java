package com.cg.user.ui;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.user.dto.Employee;


public class MyTest 
{
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ApplicationContext app=new ClassPathXmlApplicationContext("spring.xml");
		
		Employee emp= (Employee) app.getBean("emp");
		emp.getAllEmpDetails();
	}
}
