package com.cg.springspel.ui;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.springspel.dto.PrintEmployeedetail;

public class MyTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ApplicationContext ap=new ClassPathXmlApplicationContext("spring.xml");
		PrintEmployeedetail pemp=(PrintEmployeedetail) ap.getBean("print");
		pemp.getAllDetail();
	}

}
