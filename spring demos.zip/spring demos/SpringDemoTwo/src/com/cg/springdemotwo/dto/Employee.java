package com.cg.springdemotwo.dto;

public class Employee implements EmployeeDetail
{
	int empId;
	String empName;
	
	
	public Employee() {
		
		// TODO Auto-generated constructor stub
	}
	Employee(int empId,String empName)
	{
		this.empId=empId;
		this.empName=empName;
	}


	@Override
	public void getAllEmployeeDetail() 
	{
		// TODO Auto-generated method stub
		System.out.println("Id is "+empId);
		System.out.println("Name is "+empName);
	}

}
