package com.cg.springdemotwo.dto;

public interface EmployeeDetail
{
	public void getAllEmployeeDetail();
}
