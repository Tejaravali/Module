package com.cg.springobject.dto;

public interface EmployeeDetail
{
	public void getAllEmployeeDetail();
}
