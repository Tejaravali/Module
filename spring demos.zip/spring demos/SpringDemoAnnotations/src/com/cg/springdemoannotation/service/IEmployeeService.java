package com.cg.springdemoannotation.service;

public interface IEmployeeService
{
	public void getData();
}
