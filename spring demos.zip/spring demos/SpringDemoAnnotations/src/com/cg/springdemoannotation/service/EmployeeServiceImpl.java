package com.cg.springdemoannotation.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.springdemoannotation.dao.IEmployeeDao;

@Component("employeeservice")
public class EmployeeServiceImpl implements IEmployeeService 
{
	@Autowired
	IEmployeeDao employeedao;
	@Override
	public void getData() {
		// TODO Auto-generated method stub
		System.out.println("In Service layer");
		employeedao.getData();
	}

}
