package com.cg.springdemoannotation.dao;

public interface IEmployeeDao
{
	public void getData();
}
