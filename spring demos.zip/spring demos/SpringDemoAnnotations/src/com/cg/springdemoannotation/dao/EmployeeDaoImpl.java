package com.cg.springdemoannotation.dao;

import org.springframework.stereotype.Component;

@Component("employeedao")
public class EmployeeDaoImpl implements IEmployeeDao
{

	@Override
	public void getData() {
		// TODO Auto-generated method stub
		System.out.println("IN Dao layer....");
	}

}
