package com.cg.sc.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.sc.dto.Product;
import com.cg.sc.service.IProductService;

@Controller
public class ProductController 
{
	@Autowired
	IProductService productService;
	@RequestMapping(value="showAllProduct",method=RequestMethod.GET)
	public ModelAndView getAllProduct(@ModelAttribute("product") Product product )
	{
		List<Product> pList=productService.getAllProduct();
		return new ModelAndView("ShowAllProducts","temp",pList);
	}
	@RequestMapping(value="updateProduct",method=RequestMethod.GET)
	public ModelAndView updateProduct(@RequestParam("id") int proId,Map<String,Object> model,@ModelAttribute("product") Product product )
	{
		List<String> category=new ArrayList<String>();
		category.add("Home");
		category.add("Electronics");
		category.add("Furniture");
		model.put("cat", category);
		Product pro=productService.fetchProductById(proId);
		return new ModelAndView("UpdateProduct","temp",pro);
	}
	@RequestMapping(value="update",method=RequestMethod.POST)
	public String update(@ModelAttribute("product") Product product )
	{
		productService.updateProductById(product);
		return "UpdateSuccess";
	}
}