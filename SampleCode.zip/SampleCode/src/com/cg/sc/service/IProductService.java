package com.cg.sc.service;

import java.util.List;

import com.cg.sc.dto.Product;

public interface IProductService {
	List<Product> getAllProduct();
	public void updateProductById(Product product);
	public Product fetchProductById(int productId);
}
