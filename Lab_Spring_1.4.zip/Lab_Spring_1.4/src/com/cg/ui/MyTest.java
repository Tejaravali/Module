package com.cg.ui;

import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.dto.Employee;
import com.cg.service.EmpServiceImpl;

public class MyTest {

	public static void main(String args[])
	{
		ApplicationContext app = new ClassPathXmlApplicationContext("spring.xml");
		EmpServiceImpl eSer = (EmpServiceImpl) app.getBean("empSer");
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter empId to search corresponding employee details");
		int empId= sc.nextInt();
		Employee e = eSer.getEmpList(empId);
		System.out.println(e.toString());
	}
}
