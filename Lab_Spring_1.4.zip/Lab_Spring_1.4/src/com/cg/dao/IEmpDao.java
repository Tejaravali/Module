package com.cg.dao;

import com.cg.dto.Employee;

public interface IEmpDao {

	Employee getEmpList(int empId);
}
