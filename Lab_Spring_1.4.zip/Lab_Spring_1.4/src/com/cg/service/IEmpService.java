package com.cg.service;

import com.cg.dto.Employee;

public interface IEmpService {

	Employee getEmpList(int empId);
}
