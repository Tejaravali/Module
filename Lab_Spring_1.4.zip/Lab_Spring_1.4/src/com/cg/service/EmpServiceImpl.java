package com.cg.service;


import com.cg.dao.EmpDaoImpl;
import com.cg.dto.Employee;

public class EmpServiceImpl implements IEmpService {

	EmpDaoImpl employeedao;
	
	public EmpDaoImpl getEmployeedao() {
		return employeedao;
	}

	public void setEmployeedao(EmpDaoImpl employeedao) {
		this.employeedao = employeedao;
	}

	@Override
	public Employee getEmpList(int empId) {
		
		return employeedao.getEmpList(empId);
	}

}
