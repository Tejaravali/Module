package com.cg.traineemvc.dao;

import java.util.List;

import com.cg.traineemvc.dto.Trainee;

public interface ITraineeDao 
{
	public int addTrainee(Trainee trn);
	public void deleteTrainee(int traineeId);
	public List<Trainee> showAllTrainees();
	void updateRecord(Trainee record);
	public List<Trainee> showTraineeById(int traineeId);
}
