package com.cg.traineemvc.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;


import com.cg.traineemvc.dto.Trainee;

@Repository("traineedao")

public class TraineeDaoImpl implements ITraineeDao
{
	@PersistenceContext
	EntityManager entitymanager;
	@Override
	public int addTrainee(Trainee trn) {
		// TODO Auto-generated method stub
		entitymanager.persist(trn);
		entitymanager.flush();
		return trn.getTraineeId();
	}

	@Override
	public void deleteTrainee(int traineeId) {
		// TODO Auto-generated method stub
		Query queryTwo=entitymanager.createQuery("DELETE FROM Trainee WHERE traineeId=:tId");
		queryTwo.setParameter("tId", traineeId);
		queryTwo.executeUpdate();
		
	}

	@Override
	public List<Trainee> showAllTrainees() {
		// TODO Auto-generated method stub
		Query queryOne=entitymanager.createQuery("FROM Trainee");
		List<Trainee> myList= queryOne.getResultList();
		return myList;
	}

	@Override
	public void updateRecord(Trainee record) 
	{
		entitymanager.merge(record);
		entitymanager.flush();
		
	}

	@Override
	public List<Trainee> showTraineeById(int traineeId) 
	{
		Query queryTwo=entitymanager.createQuery("SELECT t FROM Trainee t WHERE traineeId=:tid");
		queryTwo.setParameter("tid", traineeId);
		List<Trainee> myList= queryTwo.getResultList();
		return myList;
	}

}
