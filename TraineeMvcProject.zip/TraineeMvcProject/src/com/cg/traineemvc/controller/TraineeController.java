package com.cg.traineemvc.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;



import org.springframework.web.bind.annotation.RequestParam;

import com.cg.traineemvc.dto.Login;
import com.cg.traineemvc.dto.Trainee;
import com.cg.traineemvc.service.ITraineeService;

@Controller
public class TraineeController
{
	@Autowired
	ITraineeService traineeservice;
	
	@RequestMapping(value="LoginPage",method=RequestMethod.GET)
	public String getAll(Model model)
	{
		Login user = new Login();
		model.addAttribute("userBean",user);
		return "index1";
	}
	
	@RequestMapping(value="login",method=RequestMethod.POST)
	public String trainee(@ModelAttribute("userBean")Login bean,Model model)
	{
		if(bean.getuName().equals("capgemini") && bean.getPwd().equals("capgemini"))
		{
			return "showList";
		}
		else
		{
			model.addAttribute("message", "Invalid User Name and Password");
			return "error";
		}

	}
	
	@RequestMapping(value="addTrainee",method=RequestMethod.GET)
	    public String showAddTrainee(@ModelAttribute("my") Trainee trn,Map<String,Object> model){
		List<String> myDom=new ArrayList<>();
		myDom.add("JEE");
		myDom.add(".NET");
		myDom.add("SAP");
		myDom.add("BI");
		model.put("dom", myDom);
		return "addTrainee";
	}
	
	@RequestMapping(value="addTraineeDetails",method=RequestMethod.POST)
	public String addTraineeDetails(@ModelAttribute ("my")Trainee trn,Map<String,Object> model)
	{
		
		int id = traineeservice.addTrainee(trn);
		return "showList";
	}
	

	@RequestMapping(value="deleteTrainne",method=RequestMethod.GET)
	public String delShow()
	{
		return "delete";
	}
	
	
	@RequestMapping(value="dodeleteTrainee",method=RequestMethod.GET)
	public String deleteTrainnee(@RequestParam ("tid") int id)
	{
		traineeservice.deleteTrainee(id);
		return "delsuccess";
		
	}
	
	

}
