package com.cg.traineemvc.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.validator.constraints.NotEmpty;


@Entity
@Table(name="logindetails")
public class Login 
{
	@Id
	@Column(name="user_name")
	@NotEmpty(message="Name should not be empty")
	private String uName;
	@Column(name="password")
	@NotEmpty(message="minimum 6 characters allowed")
	private String pwd;
	public String getuName() {
		return uName;
	}
	public void setuName(String uName) {
		this.uName = uName;
	}
	public String getPwd() {
		return pwd;
	}
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	
	
}
