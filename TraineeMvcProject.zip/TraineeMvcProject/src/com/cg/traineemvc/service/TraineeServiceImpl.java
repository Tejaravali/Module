package com.cg.traineemvc.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.traineemvc.dao.ITraineeDao;
import com.cg.traineemvc.dto.Trainee;

@Service("traineeservice")
@Transactional

public class TraineeServiceImpl implements ITraineeService{
	
	@Autowired
	ITraineeDao traineedao;
	@Override
	public int addTrainee(Trainee trn) {
		// TODO Auto-generated method stub
		 return traineedao.addTrainee(trn);
	}

	@Override
	public void deleteTrainee(int traineeId) {
		// TODO Auto-generated method stub
		traineedao.deleteTrainee(traineeId);
		
	}

	@Override
	public List<Trainee> RetrieveAllTrainees() {
		// TODO Auto-generated method stub
		return traineedao.RetrieveAllTrainees();
	}

}
