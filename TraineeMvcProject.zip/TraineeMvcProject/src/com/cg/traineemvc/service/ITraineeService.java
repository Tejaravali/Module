package com.cg.traineemvc.service;

import java.util.List;

import com.cg.traineemvc.dto.Trainee;

public interface ITraineeService
{
	public int addTrainee(Trainee trn);
	public void deleteTrainee(int traineeId);
	public List<Trainee> showAllTrainees();
	void updateRecord(Trainee record);
	public List<Trainee> showTraineeById(int traineeId);
}
