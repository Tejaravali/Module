package com.cg.springdemo6.ui;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.springdemo6.dto.printEmployeedetail;

public class MyTest {

	public static void main(String[] args) {
		ApplicationContext ap=new ClassPathXmlApplicationContext("spring.xml");
		printEmployeedetail pemp=(printEmployeedetail) ap.getBean("print");
		pemp.getAllDetail();
	}

}
