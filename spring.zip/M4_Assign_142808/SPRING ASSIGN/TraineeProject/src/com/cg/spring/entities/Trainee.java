package com.cg.spring.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Trainee_master")
public class Trainee implements Serializable{
	
	@Id
	@Column(name="trainee_id")
	private int tId;
	
	@Column(name="trainee_name")
	private String tName;
	private String tLocation;
	private String tDomain;
	public int gettId() {
		return tId;
	}
	public void settId(int tId) {
		this.tId = tId;
	}
	public String gettName() {
		return tName;
	}
	public void settName(String tName) {
		this.tName = tName;
	}
	public String gettLocation() {
		return tLocation;
	}
	public void settLocation(String tLocation) {
		this.tLocation = tLocation;
	}
	public String gettDomain() {
		return tDomain;
	}
	public void settDomain(String tDomain) {
		this.tDomain = tDomain;
	}
	@Override
	public String toString() {
		return "Trainee [tId=" + tId + ", tName=" + tName + ", tLocation="
				+ tLocation + ", tDomain=" + tDomain + "]";
	}
	
	
}
