package com.cg.spring.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.spring.dao.TraineeDao;
import com.cg.spring.entities.Trainee;

@Service
@Transactional
public class TraineeServiceImpl implements TraineeService {

	@Autowired
	TraineeDao dao;
	
	@Override
	public int addTrainee(Trainee trainee) {
		// TODO Auto-generated method stub
		return dao.addTrainee(trainee);
	}

	@Override
	public int deleteTraine(Trainee id) {
		// TODO Auto-generated method stub
		return dao.deleteTraine(id);
	}

	@Override
	public Trainee fetchRecord(Trainee id) {
		// TODO Auto-generated method stub
		return dao.fetchRecord(id);
	}

	@Override
	public void updateRecord(Trainee record) {
		// TODO Auto-generated method stub
		dao.updateRecord(record);
	}

	@Override
	public Trainee singleRecord(Trainee id) {
		// TODO Auto-generated method stub
		return dao.singleRecord(id);
	}

	@Override
	public ArrayList<Trainee> showAll() {
		// TODO Auto-generated method stub
		return dao.showAll();
	}
	
}
