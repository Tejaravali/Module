package com.cg.soap.webservice.dao;

import java.util.ArrayList;

import javax.jws.WebService;

import com.cg.soap.webservice.entity.Products;
@WebService(endpointInterface="com.cg.soap.webservice.dao.ProductDAO")
public class ProductDAOImpl {
	ArrayList<Products> list=new ArrayList<>();
	public ProductDAOImpl()
	{
		Products p=new Products();
		p.setName("pen");
		p.setPrice(1000);
		list.add(p);
		Products p1=new Products();
		p1.setName("pencil");
		p1.setPrice(2000);
		list.add(p1);
		Products p2=new Products();
		p2.setName("eraser");
		p2.setPrice(3000);
		list.add(p2);
	}
	public int getProductPrice(String product)
	{
		for(Products l:list){
		if(product.equals(l.getName()))
			return l.getPrice();
		}
		return 0;
	}
}
