package com.cg.product.service;

import java.util.List;

import com.cg.product.beans.Product;
import com.cg.product.dao.ProductsDAO;
import com.cg.product.dao.ProductsDAOImpl;

public class ProductServiceImpl implements ProductService {

	ProductsDAO dao;
	public ProductServiceImpl()
	{
		dao=new ProductsDAOImpl();
	}
	@Override
	public List<Product> getProducts() {
		return dao.getProducts();
	}

	@Override
	public Product addProduct(Product product) {
		return dao.addProduct(product);
	}

}
