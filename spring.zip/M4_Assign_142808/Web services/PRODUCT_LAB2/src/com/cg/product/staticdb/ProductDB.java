package com.cg.product.staticdb;

import java.util.HashMap;

import com.cg.product.beans.Product;

public class ProductDB {
	static HashMap<Integer,Product> productList=getProducts();
	static{
		if(productList==null)
		{
			productList=new HashMap<Integer,Product>();
			Product p1=new Product();
			p1.setId(1);
			p1.setName("pencil");
			p1.setPrice(1000);
			Product p2=new Product();
			p2.setId(2);
			p2.setName("pen");
			p2.setPrice(2000);
			Product p3=new Product();
			p3.setId(3);
			p3.setName("book");
			p3.setPrice(3000);
			productList.put(1,p1);
			productList.put(2,p2);
			productList.put(3,p3);
		}
	}
	public static HashMap<Integer,Product> getProducts()
	{
		return productList;
	}

}
